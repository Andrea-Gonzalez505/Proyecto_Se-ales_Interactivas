# Resumen Ejecutivo del Protocolo

- **Pregunta de investigación:** ¿Cómo difieren la recuperación de FC a los 60 s (`HRR60`) y la respuesta cronotrópica (`ΔFC`) entre una sesión de caminadora y una de sentadillas, de duración e intensidad relativa comparables, en seis estudiantes universitarios?
- **Diseño:** Contrabalanceado intrasujeto ($n=6$), con recorte de `4.0 s` de calibración y 7 fases protocolares (`0` a `1620 s`).
- **Análisis:** Descriptivo no paramétrico (trayectorias individuales, diferencias pareadas intrasujeto y estratificación por sexo mediante mediana y amplitud).
