# Bitácora de Inspección Visual y Latencias de Transición

| Participante | Sexo | Orden | Latencia Estímulo 1 (s) | Latencia Estímulo 2 (s) | Observaciones de calidad ECG filtrado |
| :--- | :---: | :--- | :---: | :---: | :--- |
| Juan Manuel | M | Sentadillas -> Caminadora | < 3.0 | < 3.0 | Pendiente revisión |
| Diego | M | Sentadillas -> Caminadora | < 3.0 | < 3.0 | Pendiente revisión |
| Camila | F | Sentadillas -> Caminadora | < 3.0 | < 3.0 | Pendiente revisión |
| Solangie | F | Caminadora -> Sentadillas | < 3.0 | < 3.0 | Pendiente revisión |
| Andrea | F | Caminadora -> Sentadillas | < 3.0 | < 3.0 | Pendiente revisión |
| Brayan | M | Caminadora -> Sentadillas | < 3.0 | < 3.0 | Pendiente revisión |
