import pandas as pd
import streamlit as st
from ecg_hrr_hrv_lab.analysis import compute_paired_modality_differences, summarize_nonparametric
from ecg_hrr_hrv_lab.config import RESULTS_DIR

st.header("4. Comparación Pareada (Caminadora vs. Sentadillas) y Estratificación por Sexo")

mod_path = RESULTS_DIR / "metricas_participante_modalidad.csv"
if not mod_path.exists():
    st.info("Ejecuta `uv run python scripts/run_processing.py` para generar las tablas comparativas.")
else:
    df_mod = pd.read_csv(mod_path)
    sexos = st.multiselect("Filtrar por sexo", sorted(df_mod["sexo"].unique()), default=sorted(df_mod["sexo"].unique()))
    df_f = df_mod[df_mod["sexo"].isin(sexos)]

    metrics = [
        "fc_basal_lpm", "fc_pico_lpm", "delta_fc_lpm",
        "hrr60_lpm", "hrr120_lpm", "rmssd_ms", "sdnn_ms", "cvnn_pct", "lf_ms2", "hf_ms2"
    ]

    st.subheader("Resultados individuales por participante y modalidad")
    st.dataframe(df_f, use_container_width=True)

    st.subheader("Diferencias intrasujeto (Caminadora − Sentadillas)")
    st.dataframe(compute_paired_modality_differences(df_f, metrics), use_container_width=True)

    st.subheader("Estadística descriptiva no paramétrica por Modalidad y Sexo (Mediana y Amplitud)")
    st.dataframe(summarize_nonparametric(df_f, ["modalidad", "sexo"], metrics), use_container_width=True)
