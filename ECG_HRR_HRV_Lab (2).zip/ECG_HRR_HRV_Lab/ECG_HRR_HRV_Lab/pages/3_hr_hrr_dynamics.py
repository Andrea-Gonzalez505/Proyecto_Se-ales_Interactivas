import streamlit as st
from ecg_hrr_hrv_lab.config import DATA_DIR, PARTICIPANTS
from ecg_hrr_hrv_lab.io import load_ecg_from_excel
from ecg_hrr_hrv_lab.preprocessing import filter_ecg_bandpass
from ecg_hrr_hrv_lab.qrs import detect_r_peaks_wfdb
from ecg_hrr_hrv_lab.quality import build_rr_quality_mask
from ecg_hrr_hrv_lab.rr import compute_instantaneous_and_smoothed_hr
from ecg_hrr_hrv_lab.visualization import figure_to_bytes, plot_hr_trajectory_with_events

st.header("3. Dinámica de Frecuencia Cardíaca y Recuperación (HRR60 / HRR120)")

user = st.selectbox("Participante", [p.participant_id for p in PARTICIPANTS])
meta = next(p for p in PARTICIPANTS if p.participant_id == user)
t_start, t_end = st.slider("Rango temporal (s)", 0.0, 1620.0, (0.0, 1620.0), step=10.0)

filepath = DATA_DIR / meta.filename
if not filepath.exists():
    st.warning(f"No se encontró `{filepath}`.")
else:
    t, raw_v, fs = load_ecg_from_excel(filepath)
    ecg_filt = filter_ecg_bandpass(raw_v, fs)
    del raw_v
    r_peaks = detect_r_peaks_wfdb(ecg_filt, fs)
    rr_times, rr_s, _ = build_rr_quality_mask(r_peaks, fs)
    fc_inst, fc_smooth = compute_instantaneous_and_smoothed_hr(rr_times, rr_s, win_sec=5.0)

    fig = plot_hr_trajectory_with_events(
        rr_times, fc_inst, fc_smooth, t_start, t_end,
        title=f"{meta.participant_id} — Trayectoria de FC (1º: {meta.estimulo_1} | 2º: {meta.estimulo_2})"
    )
    st.pyplot(fig)
    st.download_button(
        "Exportar trayectoria FC (PNG 300 dpi)",
        data=figure_to_bytes(fig, fmt="png"),
        file_name=f"{meta.participant_id}_trayectoria_fc.png",
        mime="image/png",
    )
