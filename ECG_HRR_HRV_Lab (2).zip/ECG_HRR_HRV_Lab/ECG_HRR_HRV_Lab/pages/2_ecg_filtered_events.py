import streamlit as st
from ecg_hrr_hrv_lab.config import DATA_DIR, PARTICIPANTS
from ecg_hrr_hrv_lab.io import load_ecg_from_excel
from ecg_hrr_hrv_lab.preprocessing import filter_ecg_bandpass
from ecg_hrr_hrv_lab.qrs import detect_r_peaks_wfdb
from ecg_hrr_hrv_lab.visualization import figure_to_bytes, plot_filtered_ecg_with_events

st.header("2. Visor de ECG Filtrado, Ondas R y Eventos del Protocolo")
st.caption("Por diseño del estudio, esta vista presenta únicamente la señal ECG ya filtrada junto con las marcas de eventos.")

user = st.selectbox("Participante", [p.participant_id for p in PARTICIPANTS])
meta = next(p for p in PARTICIPANTS if p.participant_id == user)
t_start, t_end = st.slider("Ventana temporal post-calibración (s)", 0.0, 1620.0, (475.0, 680.0), step=5.0)

filepath = DATA_DIR / meta.filename
if not filepath.exists():
    st.warning(f"No se encontró `{filepath}`. Copia los archivos `.xlsx` en `data/Registros_A_Procesamiento/`.")
else:
    t, raw_v, fs = load_ecg_from_excel(filepath)
    ecg_filt = filter_ecg_bandpass(raw_v, fs)
    del raw_v  # Se descarta la señal cruda inmediatamente tras el filtrado
    r_peaks = detect_r_peaks_wfdb(ecg_filt, fs)

    fig = plot_filtered_ecg_with_events(
        t, ecg_filt, r_peaks, t_start, t_end,
        title=f"{meta.participant_id} ({meta.sexo}) — ECG Filtrado y Eventos ({meta.orden_secuencia})"
    )
    st.pyplot(fig)
    st.download_button(
        "Exportar figura ECG filtrado (PNG 300 dpi)",
        data=figure_to_bytes(fig, fmt="png"),
        file_name=f"{meta.participant_id}_ecg_filtrado_eventos.png",
        mime="image/png",
    )
