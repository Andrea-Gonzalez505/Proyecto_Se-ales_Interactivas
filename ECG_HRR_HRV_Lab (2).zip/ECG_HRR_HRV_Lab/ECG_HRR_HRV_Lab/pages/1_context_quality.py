import pandas as pd
import streamlit as st
from ecg_hrr_hrv_lab.config import DATA_DIR, RESULTS_DIR
from ecg_hrr_hrv_lab.inventory import build_dataset_inventory

st.header("1. Contexto del Protocolo, Contrabalanceo y Bitácora de Calidad")

st.subheader("Inventario de Participantes y Orden de Estímulos")
st.dataframe(build_dataset_inventory(DATA_DIR), use_container_width=True)

qual_path = RESULTS_DIR / "bitacora_calidad.csv"
if qual_path.exists():
    st.subheader("Bitácora de Calidad por Fase (Regla de exclusión VFC > 5%)")
    df_q = pd.read_csv(qual_path)
    st.dataframe(df_q, use_container_width=True)
else:
    st.info("Ejecuta `uv run python scripts/run_processing.py` para poblar `results/bitacora_calidad.csv`.")
