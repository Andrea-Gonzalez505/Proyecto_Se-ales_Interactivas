import streamlit as st

st.header("5. Metodología, Ecuaciones y Consideraciones de Muestra Piloto (n = 6)")
st.markdown(
    """
    ### Preprocesamiento y Segmentación
    - **Calibración:** Descarte automático de los primeros `4.0 s` (`CALIBRACION_SEG = 4.0`).
    - **Filtrado:** Butterworth pasa banda (`0.5–40 Hz`, orden 3, fase cero con `filtfilt`) para preservar la morfología del complejo QRS.
    - **Detección R:** Algoritmo `XQRS` de `wfdb` con refinamiento al máximo local en ventana de `±40 ms`.
    - **Control de calidad:** Exclusión de ventanas para VFC cuando más del `5%` de intervalos R-R fueron corregidos o eliminados.

    ### Definiciones Matemáticas
    - $RR_i = (r_{i+1} - r_i) / f_s$ (en s), $FC_i = 60 / RR_i$ (en lpm).
    - $\\Delta FC = FC_{\\text{PICO}} - FC_{\\text{BASAL}}$.
    - $HRR_{60} = FC_{\\text{PICO}} - FC_{\\text{REC}}(60\\text{ s})$ y $HRR_{120} = FC_{\\text{PICO}} - FC_{\\text{REC}}(120\\text{ s})$ (mediana en ventana de `10 s`).
    - **VFC Frecuencia:** Remuestreo uniforme a `4 Hz`, eliminación de media (DC), ventana de Hanning y PSD por FFT en bandas `LF (0.04–0.15 Hz)` y `HF (0.15–0.40 Hz)`.

    ### Alcance Estadístico
    Dado el tamaño piloto ($n = 6$), se reportan trayectorias individuales, diferencias intrasujeto y estadísticos no paramétricos (mediana y amplitud) sin inferencia poblacional.
    """
)
