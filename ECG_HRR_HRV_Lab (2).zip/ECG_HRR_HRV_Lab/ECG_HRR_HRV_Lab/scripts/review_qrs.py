from ecg_hrr_hrv_lab.config import DATA_DIR, PARTICIPANTS
from ecg_hrr_hrv_lab.io import load_ecg_from_excel
from ecg_hrr_hrv_lab.preprocessing import filter_ecg_bandpass
from ecg_hrr_hrv_lab.qrs import detect_r_peaks_wfdb
from ecg_hrr_hrv_lab.quality import build_rr_quality_mask


def main() -> None:
    """Resumen rápido de frecuencia de muestreo estimada y conteo de latidos R por registro."""
    for p in PARTICIPANTS:
        fp = DATA_DIR / p.filename
        if not fp.exists():
            print(f"{p.participant_id}: archivo pendiente ({fp})")
            continue
        t, raw_v, fs = load_ecg_from_excel(fp)
        ecg_filt = filter_ecg_bandpass(raw_v, fs)
        del raw_v
        peaks = detect_r_peaks_wfdb(ecg_filt, fs)
        _, _, valid = build_rr_quality_mask(peaks, fs)
        pct_ok = 100.0 * valid.mean() if len(valid) > 0 else 0.0
        print(f"{p.participant_id:12s} | fs={fs:6.1f} Hz | dur={t[-1]:6.1f} s | R_peaks={len(peaks):4d} | RR_validos={pct_ok:5.1f}%")


if __name__ == "__main__":
    main()
