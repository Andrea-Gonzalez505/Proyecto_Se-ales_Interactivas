import subprocess
import sys


def main() -> None:
    """Ejecuta pruebas unitarias y regenera todas las tablas de resultados."""
    subprocess.run([sys.executable, "-m", "pytest", "-v"], check=True)
    subprocess.run([sys.executable, "scripts/build_inventory.py"], check=True)
    subprocess.run([sys.executable, "scripts/run_processing.py"], check=True)


if __name__ == "__main__":
    main()
