from ecg_hrr_hrv_lab.config import DATA_DIR, RESULTS_DIR
from ecg_hrr_hrv_lab.inventory import build_dataset_inventory


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    df = build_dataset_inventory(DATA_DIR)
    df.to_csv(RESULTS_DIR / "inventario_participantes.csv", index=False)
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()
