import pandas as pd
from ecg_hrr_hrv_lab.analysis import compute_paired_modality_differences, summarize_nonparametric
from ecg_hrr_hrv_lab.config import DATA_DIR, PARTICIPANTS, RESULTS_DIR
from ecg_hrr_hrv_lab.hrv import compute_hrv_metrics
from ecg_hrr_hrv_lab.io import load_ecg_from_excel
from ecg_hrr_hrv_lab.preprocessing import filter_ecg_bandpass
from ecg_hrr_hrv_lab.qrs import detect_r_peaks_wfdb
from ecg_hrr_hrv_lab.quality import build_rr_quality_mask, evaluate_phase_quality
from ecg_hrr_hrv_lab.rr import compute_chronotropic_and_hrr_metrics
from ecg_hrr_hrv_lab.validation import validate_seating_latencies


def main() -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    mod_rows, qual_dfs = [], []

    for p in PARTICIPANTS:
        for warn in validate_seating_latencies(p):
            print(f"[ADVERTENCIA] {warn}")

        filepath = DATA_DIR / p.filename
        if not filepath.exists():
            print(f"[OMITIDO] No se encontró {filepath}")
            continue

        t, raw_v, fs = load_ecg_from_excel(filepath)
        ecg_filt = filter_ecg_bandpass(raw_v, fs)
        del raw_v

        r_peaks = detect_r_peaks_wfdb(ecg_filt, fs)
        rr_times, rr_s, valid_mask = build_rr_quality_mask(r_peaks, fs)
        qual_dfs.append(evaluate_phase_quality(p.participant_id, p.sexo, rr_times, valid_mask))

        for mod, (s0, s1, r0, r1, lat) in [
            (p.estimulo_1, (480.0, 660.0, 660.0, 960.0, p.latencia_est1_s)),
            (p.estimulo_2, (1140.0, 1320.0, 1320.0, 1620.0, p.latencia_est2_s)),
        ]:
            chrono = compute_chronotropic_and_hrr_metrics(rr_times, rr_s, valid_mask, s0, s1)
            hrv = compute_hrv_metrics(rr_times, rr_s, valid_mask, r0, r1)
            mod_rows.append({
                "participant_id": p.participant_id,
                "sexo": p.sexo,
                "orden_secuencia": p.orden_secuencia,
                "modalidad": mod,
                "latencia_sedestacion_s": lat,
                **chrono,
                **hrv,
            })

    if not mod_rows:
        print("No se procesaron archivos. Verifica que los .xlsx estén en data/Registros_A_Procesamiento/.")
        return

    df_mod = pd.DataFrame(mod_rows)
    df_qual = pd.concat(qual_dfs, ignore_index=True)
    metrics = [
        "fc_basal_lpm", "fc_pico_lpm", "delta_fc_lpm",
        "hrr60_lpm", "hrr120_lpm", "rmssd_ms", "sdnn_ms", "cvnn_pct", "lf_ms2", "hf_ms2"
    ]

    df_mod.to_csv(RESULTS_DIR / "metricas_participante_modalidad.csv", index=False)
    df_qual.to_csv(RESULTS_DIR / "bitacora_calidad.csv", index=False)
    compute_paired_modality_differences(df_mod, metrics).to_csv(
        RESULTS_DIR / "comparacion_pareada_modalidad.csv", index=False
    )
    summarize_nonparametric(df_mod, ["modalidad", "sexo"], metrics).to_csv(
        RESULTS_DIR / "resumen_descriptivo_sexo.csv", index=False
    )
    print("Procesamiento completado. Resultados guardados en results/.")


if __name__ == "__main__":
    main()
