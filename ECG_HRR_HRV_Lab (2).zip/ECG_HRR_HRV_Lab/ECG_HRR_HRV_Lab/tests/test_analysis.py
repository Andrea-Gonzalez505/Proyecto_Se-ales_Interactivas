import pandas as pd
from ecg_hrr_hrv_lab.analysis import compute_paired_modality_differences, summarize_nonparametric


def test_paired_and_nonparametric_summary():
    df = pd.DataFrame([
        {"participant_id": "A", "sexo": "F", "orden_secuencia": "caminadora_primero", "modalidad": "caminadora", "hrr60_lpm": 32.0},
        {"participant_id": "A", "sexo": "F", "orden_secuencia": "caminadora_primero", "modalidad": "sentadillas", "hrr60_lpm": 26.0},
        {"participant_id": "B", "sexo": "M", "orden_secuencia": "sentadillas_primero", "modalidad": "caminadora", "hrr60_lpm": 38.0},
        {"participant_id": "B", "sexo": "M", "orden_secuencia": "sentadillas_primero", "modalidad": "sentadillas", "hrr60_lpm": 30.0},
    ])
    paired = compute_paired_modality_differences(df, ["hrr60_lpm"])
    assert list(paired["delta_hrr60_lpm_cam_menos_sen"]) == [6.0, 8.0]

    summ = summarize_nonparametric(df, ["modalidad"], ["hrr60_lpm"])
    assert len(summ) == 2
