import numpy as np
from ecg_hrr_hrv_lab.rr import compute_chronotropic_and_hrr_metrics


def test_chronotropic_and_hrr_metrics_exact():
    t_basal = np.arange(240.0, 300.5, 1.0)
    rr_basal = np.ones_like(t_basal)

    t_stim = np.arange(480.0, 660.2, 0.4)
    rr_stim = np.full_like(t_stim, 0.4)

    t_rec = np.arange(661.0, 800.0, 0.6)
    rr_rec = np.full_like(t_rec, 0.6)

    rr_times = np.concatenate([t_basal, t_stim, t_rec])
    rr_s = np.concatenate([rr_basal, rr_stim, rr_rec])
    valid = np.ones_like(rr_s, dtype=bool)

    res = compute_chronotropic_and_hrr_metrics(rr_times, rr_s, valid, 480.0, 660.0)
    assert np.isclose(res["fc_basal_lpm"], 60.0)
    assert np.isclose(res["fc_pico_lpm"], 150.0)
    assert np.isclose(res["delta_fc_lpm"], 90.0)
    assert np.isclose(res["hrr60_lpm"], 50.0)
    assert np.isclose(res["hrr120_lpm"], 50.0)
