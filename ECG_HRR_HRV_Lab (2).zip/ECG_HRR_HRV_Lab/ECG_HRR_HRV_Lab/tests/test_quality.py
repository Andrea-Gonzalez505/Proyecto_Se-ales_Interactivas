import numpy as np
from ecg_hrr_hrv_lab.quality import build_rr_quality_mask, evaluate_phase_quality


def test_quality_mask_flags_implausible_rr():
    fs = 100.0
    r_peaks = np.array([100, 180, 260, 275, 355])
    _, _, valid = build_rr_quality_mask(r_peaks, fs)
    assert list(valid) == [True, True, False, True]


def test_evaluate_phase_quality_excludes_gt_5pct():
    rr_times = np.linspace(10.0, 290.0, 20)
    valid = np.ones(20, dtype=bool)
    valid[0] = False  # 1/20 = 5.0% -> válido
    df_ok = evaluate_phase_quality("Test", "F", rr_times, valid)
    assert not bool(df_ok.loc[df_ok["fase"] == "01_Reposo_inicial", "excluido_vfc"].iloc[0])

    valid[1] = False  # 2/20 = 10.0% > 5.0% -> excluido
    df_bad = evaluate_phase_quality("Test", "F", rr_times, valid)
    assert bool(df_bad.loc[df_bad["fase"] == "01_Reposo_inicial", "excluido_vfc"].iloc[0])
