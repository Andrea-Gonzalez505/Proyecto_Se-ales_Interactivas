import numpy as np
from ecg_hrr_hrv_lab.hrv import compute_hrv_metrics


def test_hrv_metrics_time_and_frequency():
    rr_times = np.arange(660.0, 780.0, 0.8)
    rr_s = 0.8 + 0.03 * np.sin(2.0 * np.pi * 0.25 * rr_times)  # Oscilación en banda HF (0.25 Hz)
    valid = np.ones_like(rr_s, dtype=bool)

    res = compute_hrv_metrics(rr_times, rr_s, valid, 660.0, 960.0)
    assert res["vfc_valida"] is True
    assert res["rmssd_ms"] > 0
    assert res["hf_ms2"] > res["lf_ms2"]
