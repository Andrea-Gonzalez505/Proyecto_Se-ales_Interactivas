import numpy as np
import pandas as pd
from ecg_hrr_hrv_lab.io import load_ecg_from_excel


def test_load_ecg_from_excel_reads_col2_col3_and_trims_4s(tmp_path):
    fs = 100.0
    t = np.arange(0.0, 10.0, 1.0 / fs)
    df = pd.DataFrame({
        "indice": np.arange(len(t)),
        "tiempo_s": t,
        "voltaje_mv": np.sin(2.0 * np.pi * 1.2 * t),
    })
    fpath = tmp_path / "test_ecg.xlsx"
    df.to_excel(fpath, index=False)

    t_out, v_out, fs_out = load_ecg_from_excel(fpath)
    assert np.isclose(fs_out, 100.0)
    assert np.isclose(t_out[0], 0.0)
    assert np.isclose(t_out[-1], 5.99, atol=0.02)
    assert len(t_out) == len(v_out)
