import numpy as np
from ecg_hrr_hrv_lab.qrs import detect_r_peaks_wfdb


def test_detect_r_peaks_wfdb_synthetic_train():
    fs = 250.0
    t = np.arange(0, 10, 1 / fs)
    sig = np.zeros_like(t)
    expected_peaks = np.arange(250, 2250, 250)  # 60 lpm exactos
    for p in expected_peaks:
        sig[p - 2:p + 3] = [0.2, 0.7, 1.5, 0.6, 0.1]
    peaks = detect_r_peaks_wfdb(sig, fs)
    assert len(peaks) >= 6
