import numpy as np
from ecg_hrr_hrv_lab.preprocessing import filter_ecg_bandpass


def test_filter_ecg_bandpass_removes_dc_offset():
    fs = 130.0
    t = np.arange(0, 10, 1 / fs)
    sig = 5.0 + np.sin(2 * np.pi * 2.0 * t)
    filt = filter_ecg_bandpass(sig, fs)
    assert abs(np.mean(filt)) < 0.05
