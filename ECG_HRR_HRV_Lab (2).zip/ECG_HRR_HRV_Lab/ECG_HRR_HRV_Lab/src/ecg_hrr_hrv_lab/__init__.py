"""Paquete principal para análisis de ECG filtrado, HRR y VFC en caminadora vs. sentadillas."""

__version__ = "0.2.0"
