from typing import List
import numpy as np
import pandas as pd


def compute_paired_modality_differences(df: pd.DataFrame, metrics: List[str]) -> pd.DataFrame:
    """Calcula diferencias intrasujeto (Caminadora - Sentadillas) conservando sexo y orden."""
    cam = df[df["modalidad"] == "caminadora"].set_index("participant_id")
    sen = df[df["modalidad"] == "sentadillas"].set_index("participant_id")
    rows = []
    for pid in cam.index.intersection(sen.index):
        r = {
            "participant_id": pid,
            "sexo": cam.loc[pid, "sexo"],
            "orden_secuencia": cam.loc[pid, "orden_secuencia"],
        }
        for m in metrics:
            vc, vs = cam.loc[pid, m], sen.loc[pid, m]
            r[f"{m}_caminadora"] = vc
            r[f"{m}_sentadillas"] = vs
            r[f"delta_{m}_cam_menos_sen"] = float(vc - vs) if pd.notna(vc) and pd.notna(vs) else np.nan
        rows.append(r)
    return pd.DataFrame(rows)


def summarize_nonparametric(df: pd.DataFrame, group_cols: List[str], metrics: List[str]) -> pd.DataFrame:
    """Estadística descriptiva no paramétrica (mediana y amplitud) sin valores p (n=6)."""
    rows = []
    for keys, sub in df.groupby(group_cols, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        row = dict(zip(group_cols, keys))
        row["n"] = int(sub["participant_id"].nunique())
        for m in metrics:
            vals = pd.to_numeric(sub[m], errors="coerce").dropna().to_numpy(dtype=float)
            row[f"{m}_mediana"] = float(np.median(vals)) if len(vals) > 0 else np.nan
            row[f"{m}_amplitud"] = float(np.max(vals) - np.min(vals)) if len(vals) > 0 else np.nan
        rows.append(row)
    return pd.DataFrame(rows)
