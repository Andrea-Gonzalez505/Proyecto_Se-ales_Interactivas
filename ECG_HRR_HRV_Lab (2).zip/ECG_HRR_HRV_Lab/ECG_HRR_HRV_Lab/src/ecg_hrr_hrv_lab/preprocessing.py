import numpy as np
from scipy.signal import butter, filtfilt


def filter_ecg_bandpass(
    raw_voltage: np.ndarray,
    fs: float,
    lowcut: float = 0.5,
    highcut: float = 40.0,
    order: int = 3,
) -> np.ndarray:
    """
    Aplica filtro Butterworth pasa banda zero-phase (filtfilt) para remover deriva
    de línea base (<0.5 Hz) y ruido de alta frecuencia (>40 Hz) sin deformar el QRS.
    """
    if len(raw_voltage) < int(fs * 2):
        return raw_voltage.copy()
    nyq = 0.5 * fs
    b, a = butter(order, [max(lowcut / nyq, 1e-4), min(highcut / nyq, 0.99)], btype="band")
    return filtfilt(b, a, raw_voltage)
