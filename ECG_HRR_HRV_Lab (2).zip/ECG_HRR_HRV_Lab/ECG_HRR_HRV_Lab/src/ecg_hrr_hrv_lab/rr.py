from typing import Optional, Tuple
import numpy as np
import pandas as pd
from ecg_hrr_hrv_lab.config import HRR_WINDOW_SEC


def compute_instantaneous_and_smoothed_hr(
    rr_times_s: np.ndarray,
    rr_s: np.ndarray,
    win_sec: float = 5.0,
) -> Tuple[np.ndarray, np.ndarray]:
    """Calcula FC_i = 60 / RR_i (lpm) y la suaviza con mediana móvil de 5 segundos."""
    if len(rr_s) == 0:
        return np.array([]), np.array([])
    fc_inst = 60.0 / np.maximum(rr_s, 1e-6)
    idx = pd.to_timedelta(rr_times_s, unit="s")
    fc_smooth = pd.Series(fc_inst, index=idx).sort_index().rolling(f"{win_sec}s", min_periods=1).median().to_numpy()
    return fc_inst, fc_smooth


def compute_chronotropic_and_hrr_metrics(
    rr_times_s: np.ndarray,
    rr_s: np.ndarray,
    valid_mask: np.ndarray,
    stim_start_s: float,
    stim_end_s: float,
    basal_window_s: Tuple[float, float] = (240.0, 300.0),
) -> dict:
    """
    Calcula:
      - FC_Basal: promedio en el último minuto del reposo inicial (240–300 s).
      - FC_Pico: máximo de FC suavizada (mediana móvil 5 s) en los 3 min de estímulo.
      - Delta_FC = FC_Pico - FC_Basal.
      - HRR60 = FC_Pico - FC_REC(60s) y HRR120 = FC_Pico - FC_REC(120s) (mediana en ventana de 10 s).
    """
    m_basal = valid_mask & (rr_times_s >= basal_window_s[0]) & (rr_times_s <= basal_window_s[1])
    fc_basal: Optional[float] = float(np.mean(60.0 / rr_s[m_basal])) if np.any(m_basal) else None

    m_stim = valid_mask & (rr_times_s >= stim_start_s) & (rr_times_s <= stim_end_s)
    fc_pico: Optional[float] = None
    if np.any(m_stim):
        _, fc_stim_smooth = compute_instantaneous_and_smoothed_hr(rr_times_s[m_stim], rr_s[m_stim], win_sec=5.0)
        fc_pico = float(np.max(fc_stim_smooth))

    delta_fc = (fc_pico - fc_basal) if (fc_pico is not None and fc_basal is not None) else None

    def _fcrec(offset_s: float) -> Optional[float]:
        center = stim_end_s + offset_s
        half = HRR_WINDOW_SEC / 2.0
        m_rec = valid_mask & (rr_times_s >= center - half) & (rr_times_s <= center + half)
        return float(np.median(60.0 / rr_s[m_rec])) if np.any(m_rec) else None

    fcrec_60 = _fcrec(60.0)
    fcrec_120 = _fcrec(120.0)
    hrr60 = (fc_pico - fcrec_60) if (fc_pico is not None and fcrec_60 is not None) else None
    hrr120 = (fc_pico - fcrec_120) if (fc_pico is not None and fcrec_120 is not None) else None

    return {
        "fc_basal_lpm": fc_basal,
        "fc_pico_lpm": fc_pico,
        "delta_fc_lpm": delta_fc,
        "fcrec60_lpm": fcrec_60,
        "fcrec120_lpm": fcrec_120,
        "hrr60_lpm": hrr60,
        "hrr120_lpm": hrr120,
    }
