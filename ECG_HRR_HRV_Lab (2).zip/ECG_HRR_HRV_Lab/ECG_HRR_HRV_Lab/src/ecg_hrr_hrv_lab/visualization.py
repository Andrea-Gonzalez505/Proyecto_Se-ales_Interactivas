from io import BytesIO
import matplotlib.pyplot as plt
import numpy as np
from ecg_hrr_hrv_lab.config import FASES_PROTOCOLO


def plot_filtered_ecg_with_events(
    t: np.ndarray,
    ecg_filtered: np.ndarray,
    r_peaks: np.ndarray,
    t_start: float,
    t_end: float,
    title: str,
) -> plt.Figure:
    """Grafica EXCLUSIVAMENTE la señal ECG filtrada, las ondas R y los eventos del protocolo."""
    fig, ax = plt.subplots(figsize=(12, 4))
    mask = (t >= t_start) & (t <= t_end)
    ax.plot(t[mask], ecg_filtered[mask], lw=0.9, color="#1f77b4", label="ECG filtrado (pasa banda)")

    p_win = r_peaks[(t[r_peaks] >= t_start) & (t[r_peaks] <= t_end)]
    ax.scatter(t[p_win], ecg_filtered[p_win], color="#d62728", s=18, zorder=3, label="Ondas R (WFDB)")

    y_top = float(np.nanmax(ecg_filtered[mask])) if np.any(mask) else 1.0
    for fname, f0, f1 in FASES_PROTOCOLO:
        if f1 >= t_start and f0 <= t_end:
            ax.axvline(f0, linestyle="--", color="#333333", alpha=0.65)
            ax.text(max(f0, t_start) + 1.5, y_top * 0.92, fname, rotation=90, va="top", fontsize=8)

    ax.set_title(title)
    ax.set_xlabel("Tiempo post-calibración (s)")
    ax.set_ylabel("Voltaje filtrado")
    ax.legend(loc="upper right")
    fig.tight_layout()
    return fig


def plot_hr_trajectory_with_events(
    rr_times_s: np.ndarray,
    fc_inst: np.ndarray,
    fc_smooth: np.ndarray,
    t_start: float,
    t_end: float,
    title: str,
) -> plt.Figure:
    """Grafica la frecuencia cardíaca instantánea y suavizada (5 s) con marcas de eventos."""
    fig, ax = plt.subplots(figsize=(12, 3.8))
    mask = (rr_times_s >= t_start) & (rr_times_s <= t_end)
    ax.plot(rr_times_s[mask], fc_inst[mask], alpha=0.38, lw=1.0, label="FC instantánea (lpm)")
    ax.plot(rr_times_s[mask], fc_smooth[mask], lw=2.0, color="#2ca02c", label="FC suavizada 5 s (lpm)")

    for fname, f0, f1 in FASES_PROTOCOLO:
        if f1 >= t_start and f0 <= t_end:
            ax.axvline(f0, linestyle="--", color="#333333", alpha=0.55)
    ax.set_title(title)
    ax.set_xlabel("Tiempo post-calibración (s)")
    ax.set_ylabel("FC (lpm)")
    ax.legend(loc="upper right")
    fig.tight_layout()
    return fig


def figure_to_bytes(fig: plt.Figure, fmt: str = "png", dpi: int = 300) -> bytes:
    """Serializa una figura para exportación reproducible en PNG o SVG."""
    buf = BytesIO()
    fig.savefig(buf, format=fmt, dpi=dpi, bbox_inches="tight")
    buf.seek(0)
    return buf.getvalue()
