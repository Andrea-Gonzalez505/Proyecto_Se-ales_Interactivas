from pathlib import Path
import pandas as pd
from ecg_hrr_hrv_lab.config import DATA_DIR, PARTICIPANTS


def build_dataset_inventory(data_dir: Path = DATA_DIR) -> pd.DataFrame:
    """Verifica la existencia de los .xlsx y consolida metadatos de los 6 participantes."""
    rows = []
    for p in PARTICIPANTS:
        fpath = data_dir / p.filename
        rows.append({
            "participant_id": p.participant_id,
            "sexo": p.sexo,
            "archivo": p.filename,
            "existe": fpath.exists(),
            "estimulo_1": p.estimulo_1,
            "estimulo_2": p.estimulo_2,
            "orden_secuencia": p.orden_secuencia,
            "latencia_est1_s": p.latencia_est1_s,
            "latencia_est2_s": p.latencia_est2_s,
        })
    return pd.DataFrame(rows)
