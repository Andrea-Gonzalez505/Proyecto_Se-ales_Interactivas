import numpy as np
from wfdb import processing


def detect_r_peaks_wfdb(ecg_filtered: np.ndarray, fs: float) -> np.ndarray:
    """
    Detecta ondas R de forma reproducible usando WFDB (XQRS) sobre el ECG filtrado
    y refina cada índice al máximo local dentro de +-40 ms.
    """
    if len(ecg_filtered) < int(fs):
        return np.array([], dtype=int)

    xqrs = processing.XQRS(sig=ecg_filtered, fs=fs)
    xqrs.detect(verbose=False)
    candidates = np.asarray(xqrs.qrs_inds, dtype=int)

    radius = max(1, int(0.04 * fs))
    min_dist = max(1, int(0.22 * fs))
    refined: list[int] = []
    n = len(ecg_filtered)

    for idx in candidates:
        lo, hi = max(0, idx - radius), min(n, idx + radius + 1)
        peak = lo + int(np.argmax(ecg_filtered[lo:hi]))
        if not refined or (peak - refined[-1]) >= min_dist:
            refined.append(peak)

    return np.array(refined, dtype=int)
