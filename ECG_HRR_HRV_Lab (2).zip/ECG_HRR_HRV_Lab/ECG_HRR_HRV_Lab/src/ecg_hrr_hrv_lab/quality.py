from typing import Tuple
import numpy as np
import pandas as pd
from ecg_hrr_hrv_lab.config import FASES_PROTOCOLO, MAX_RR_CORR_PCT


def build_rr_quality_mask(
    r_peaks: np.ndarray,
    fs: float,
    rr_min_s: float = 0.30,
    rr_max_s: float = 2.00,
    ectopic_tol: float = 0.25,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Calcula RR_i = (r_{i+1} - r_i) / fs (s) y genera máscara booleana de calidad:
      - Descarta intervalos fisiológicamente implausibles (<0.30 s o >2.00 s).
      - Marca latidos ectópicos o artefactos que se desvían >25% de la mediana local.
    """
    if len(r_peaks) < 2:
        return np.array([]), np.array([]), np.array([], dtype=bool)

    rr_s = np.diff(r_peaks) / float(fs)
    rr_times_s = r_peaks[1:] / float(fs)

    plausible = (rr_s >= rr_min_s) & (rr_s <= rr_max_s)
    local_med = pd.Series(rr_s).rolling(5, center=True, min_periods=1).median().to_numpy()
    non_ectopic = (np.abs(rr_s - local_med) / np.maximum(local_med, 1e-6)) <= ectopic_tol

    return rr_times_s, rr_s, (plausible & non_ectopic)


def evaluate_phase_quality(
    participant_id: str,
    sexo: str,
    rr_times_s: np.ndarray,
    valid_mask: np.ndarray,
) -> pd.DataFrame:
    """Genera la bitácora de calidad por fase aplicando la regla de exclusión VFC (>5%)."""
    records = []
    for phase_name, t0, t1 in FASES_PROTOCOLO:
        pmask = (rr_times_s >= t0) & (rr_times_s < t1)
        tot = int(np.sum(pmask))
        inv = int(np.sum(~valid_mask[pmask]))
        pct = float(100.0 * inv / tot) if tot > 0 else 100.0
        records.append({
            "participant_id": participant_id,
            "sexo": sexo,
            "fase": phase_name,
            "total_rr": tot,
            "rr_invalidos": inv,
            "pct_corregido_eliminado": round(pct, 2),
            "excluido_vfc": pct > MAX_RR_CORR_PCT,
        })
    return pd.DataFrame(records)
