from ecg_hrr_hrv_lab.config import MAX_SEATING_LATENCY_SEC, ParticipantConfig


def validate_seating_latencies(p: ParticipantConfig) -> list[str]:
    """Verifica que las latencias de transición a sedestación cumplan el criterio (< 3.0 s)."""
    warnings = []
    if p.latencia_est1_s >= MAX_SEATING_LATENCY_SEC:
        warnings.append(f"{p.participant_id}: latencia Estímulo 1 ({p.latencia_est1_s}s) >= 3.0s")
    if p.latencia_est2_s >= MAX_SEATING_LATENCY_SEC:
        warnings.append(f"{p.participant_id}: latencia Estímulo 2 ({p.latencia_est2_s}s) >= 3.0s")
    return warnings
