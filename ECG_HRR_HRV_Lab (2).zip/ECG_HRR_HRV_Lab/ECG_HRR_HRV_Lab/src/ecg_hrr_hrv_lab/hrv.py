from typing import Dict, Optional
import numpy as np
from scipy.interpolate import interp1d
from ecg_hrr_hrv_lab.config import HF_BAND_HZ, LF_BAND_HZ, MAX_RR_CORR_PCT, PSD_FS_HZ


def compute_hrv_metrics(
    rr_times_s: np.ndarray,
    rr_s: np.ndarray,
    valid_mask: np.ndarray,
    window_start_s: float,
    window_end_s: float,
) -> Dict[str, Optional[float] | bool]:
    """
    Calcula indicadores de VFC en dominio del tiempo (RMSSD, SDNN, CVNN) y frecuencia
    (remuestreo 4 Hz, remoción DC, ventana Hanning, FFT -> LF y HF en ms^2) si el
    porcentaje de intervalos corregidos/eliminados en la ventana es <= 5%.
    """
    in_win = (rr_times_s >= window_start_s) & (rr_times_s < window_end_s)
    tot = int(np.sum(in_win))
    inv = int(np.sum(~valid_mask[in_win]))
    corr_pct = float(100.0 * inv / tot) if tot > 0 else 100.0
    eligible = corr_pct <= MAX_RR_CORR_PCT

    sel = in_win & valid_mask
    if not eligible or np.sum(sel) < 8:
        return {
            "pct_rr_corregido": round(corr_pct, 2),
            "vfc_valida": False,
            "rmssd_ms": None,
            "sdnn_ms": None,
            "cvnn_pct": None,
            "lf_ms2": None,
            "hf_ms2": None,
        }

    t_v = rr_times_s[sel]
    rr_ms = rr_s[sel] * 1000.0

    # Dominio del tiempo
    rmssd = float(np.sqrt(np.mean(np.diff(rr_ms) ** 2)))
    sdnn = float(np.std(rr_ms, ddof=1))
    cvnn = float(100.0 * sdnn / np.mean(rr_ms))

    # Dominio de frecuencia (remuestreo uniforme a 4 Hz, remoción DC, Hanning y FFT)
    lf_power, hf_power = None, None
    if (t_v[-1] - t_v[0]) >= 10.0:
        t_u = np.arange(t_v[0], t_v[-1], 1.0 / PSD_FS_HZ)
        if len(t_u) >= 16:
            rr_u = interp1d(t_v, rr_ms, kind="cubic", fill_value="extrapolate")(t_u)
            rr_detrend = rr_u - np.mean(rr_u)
            win = np.hanning(len(rr_detrend))
            fft_vals = np.fft.rfft(rr_detrend * win)
            freqs = np.fft.rfftfreq(len(rr_detrend), d=1.0 / PSD_FS_HZ)
            psd = (np.abs(fft_vals) ** 2) / np.sum(win ** 2)
            if len(psd) > 2:
                psd[1:-1] *= 2.0

            lf_m = (freqs >= LF_BAND_HZ[0]) & (freqs <= LF_BAND_HZ[1])
            hf_m = (freqs >= HF_BAND_HZ[0]) & (freqs <= HF_BAND_HZ[1])
            if np.any(lf_m):
                lf_power = float(np.trapezoid(psd[lf_m], freqs[lf_m]))
            if np.any(hf_m):
                hf_power = float(np.trapezoid(psd[hf_m], freqs[hf_m]))

    return {
        "pct_rr_corregido": round(corr_pct, 2),
        "vfc_valida": True,
        "rmssd_ms": rmssd,
        "sdnn_ms": sdnn,
        "cvnn_pct": cvnn,
        "lf_ms2": lf_power,
        "hf_ms2": hf_power,
    }
