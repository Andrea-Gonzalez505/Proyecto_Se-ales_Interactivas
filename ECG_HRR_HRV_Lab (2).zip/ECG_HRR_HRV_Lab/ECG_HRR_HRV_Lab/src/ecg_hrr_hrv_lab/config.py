from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

# Segundos iniciales de calibración a descartar en todas las señales
CALIBRACION_SEG: float = 4.0

# Fases del protocolo post-calibración (nombre, inicio_seg, fin_seg)
FASES_PROTOCOLO: List[Tuple[str, float, float]] = [
    ("01_Reposo_inicial", 0.0, 300.0),
    ("02_Calentamiento_1", 300.0, 480.0),
    ("03_Estimulo_1", 480.0, 660.0),
    ("04_Reposo_2", 660.0, 960.0),
    ("05_Calentamiento_2", 960.0, 1140.0),
    ("06_Estimulo_2", 1140.0, 1320.0),
    ("07_Reposo_final", 1320.0, 1620.0),
]

# Índices de columna fijos en los archivos .xlsx (base 0: col 1 = 2ª columna, col 2 = 3ª columna)
TIME_COL_IDX: int = 1
VOLTAGE_COL_IDX: int = 2
DEFAULT_FS_HZ: float = 130.0

# Criterios de calidad y ventanas
MAX_RR_CORR_PCT: float = 5.0          # Exclusión VFC si > 5% corregido/eliminado
HRR_WINDOW_SEC: float = 10.0          # Ventana de 10 s centrada en +60 s y +120 s
MAX_SEATING_LATENCY_SEC: float = 3.0  # Latencia máxima de transición a sedestación

# Parámetros espectrales de VFC
PSD_FS_HZ: float = 4.0
LF_BAND_HZ: Tuple[float, float] = (0.04, 0.15)
HF_BAND_HZ: Tuple[float, float] = (0.15, 0.40)


@dataclass(frozen=True)
class ParticipantConfig:
    """Metadatos, orden de estímulos y latencias de transición de cada estudiante."""
    participant_id: str
    filename: str
    sexo: str  # "F" o "M" (ajustar según registro oficial del estudio)
    estimulo_1: str  # "sentadillas" o "caminadora"
    estimulo_2: str  # "sentadillas" o "caminadora"
    latencia_est1_s: float = 1.5
    latencia_est2_s: float = 1.5

    @property
    def orden_secuencia(self) -> str:
        return f"{self.estimulo_1}_primero"

    @property
    def fase_a_modalidad(self) -> Dict[str, str]:
        return {
            "03_Estimulo_1": self.estimulo_1,
            "04_Reposo_2": self.estimulo_1,
            "06_Estimulo_2": self.estimulo_2,
            "07_Reposo_final": self.estimulo_2,
        }


PARTICIPANTS: List[ParticipantConfig] = [
    ParticipantConfig("Juan Manuel", "ECG_JuanManuel_Adquisition_Nuevo.xlsx", "M", "sentadillas", "caminadora"),
    ParticipantConfig("Diego", "ECG_Diego_Adquisition_Nuevo.xlsx", "M", "sentadillas", "caminadora"),
    ParticipantConfig("Camila", "ECG_Camila_Adquisition_Nuevo.xlsx", "F", "sentadillas", "caminadora"),
    ParticipantConfig("Solangie", "ECG_Solangie_Adquisition.xlsx", "F", "caminadora", "sentadillas"),
    ParticipantConfig("Andrea", "ECG_Andrea_Adquisition.xlsx", "F", "caminadora", "sentadillas"),
    ParticipantConfig("Brayan", "ECG_Brayan_Adquisition_Nuevo.xlsx", "M", "caminadora", "sentadillas"),
]

DATA_DIR = Path("data/Registros_A_Procesamiento")
RESULTS_DIR = Path("results")
