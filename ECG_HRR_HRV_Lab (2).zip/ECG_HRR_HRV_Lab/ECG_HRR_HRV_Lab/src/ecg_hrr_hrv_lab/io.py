from pathlib import Path
from typing import Dict, Tuple
import numpy as np
import pandas as pd

from ecg_hrr_hrv_lab.config import (
    CALIBRACION_SEG,
    DEFAULT_FS_HZ,
    FASES_PROTOCOLO,
    TIME_COL_IDX,
    VOLTAGE_COL_IDX,
)


def load_ecg_from_excel(
    filepath: Path,
    time_col_idx: int = TIME_COL_IDX,
    voltage_col_idx: int = VOLTAGE_COL_IDX,
    default_fs: float = DEFAULT_FS_HZ,
) -> Tuple[np.ndarray, np.ndarray, float]:
    """
    Lee el archivo .xlsx tomando:
      - 2ª columna (índice 1) como tiempo.
      - 3ª columna (índice 2) como voltaje.
    Estima fs, descarta los primeros CALIBRACION_SEG (4.0 s) y reinicia el tiempo en 0.0 s.
    """
    df = pd.read_excel(filepath)
    if df.shape[1] <= max(time_col_idx, voltage_col_idx):
        raise ValueError(f"El archivo {filepath.name} debe tener al menos 3 columnas.")

    t_raw = pd.to_numeric(df.iloc[:, time_col_idx], errors="coerce").to_numpy(dtype=float)
    v_raw = pd.to_numeric(df.iloc[:, voltage_col_idx], errors="coerce").to_numpy(dtype=float)

    valid = ~np.isnan(t_raw) & ~np.isnan(v_raw)
    t_raw, v_raw = t_raw[valid], v_raw[valid]
    if len(t_raw) < 2:
        raise ValueError(f"Datos insuficientes en {filepath.name}.")

    dt = np.diff(t_raw)
    pos_dt = dt[dt > 0]
    fs = float(default_fs)
    if len(pos_dt) > 0:
        med_dt = float(np.median(pos_dt))
        if med_dt > 0.1:  # Conversión automática si viene en milisegundos
            t_raw = t_raw / 1000.0
            med_dt = med_dt / 1000.0
        fs = float(1.0 / med_dt)

    t_rel = t_raw - t_raw[0]
    keep = t_rel >= CALIBRACION_SEG
    return t_rel[keep] - CALIBRACION_SEG, v_raw[keep], fs


def segment_signal_by_phases(
    t: np.ndarray,
    ecg_filtered: np.ndarray,
) -> Dict[str, Tuple[np.ndarray, np.ndarray]]:
    """Segmenta la señal ECG YA FILTRADA según FASES_PROTOCOLO."""
    out: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
    for name, t0, t1 in FASES_PROTOCOLO:
        mask = (t >= t0) & (t < t1)
        out[name] = (t[mask], ecg_filtered[mask])
    return out
